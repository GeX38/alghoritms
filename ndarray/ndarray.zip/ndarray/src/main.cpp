#include "ndarray.h"
#include <iostream>
template <typename T>
void printv(const std::vector<T> &v) {
  for (const auto &item : v) {
    std::cout << item << " ";
  }
  std::cout << std::endl;
}

int main() {

  auto arr1 = ndarray<>({2, 3}, {
                                    //
                                    1, 2, 3, //
                                    4, 5, 6, //
                                });

  auto arr2 = arr1;

  auto arr5 = ndarray<>({2,3}, 7);

  std::cout <<arr5 << std::endl;

  auto arr6 = ndarray<>::zeros({2,3});

  std::cout <<arr6 << std::endl;
  
  auto arr7 = ndarray<>::ones({2,3});

  std::cout <<arr7 << std::endl;

  std::cout<<"(arr5*arr7+arr7)/(arr5-arr7-arr7-arr7)\n"<<(arr5*arr7+arr7)/(arr5-arr7-arr7-arr7)<<std::endl;
  
  auto arr8 = ndarray<>::rands({2,3});
  
  std::cout <<arr8 << std::endl;

  auto arr3 = ndarray<>({3, 2}, {
                                    //
                                    0, 1, 2, //
                                    3, 4, 5, //
                                });
  std::cout << arr3 << std::endl;
  std::cout << "mean() " << arr3.mean() << std::endl;
  std::cout << "mean(0) ";
  printv(arr3.mean(0));
  std::cout << "mean(1) ";
  printv(arr3.mean(1));
  std::cout << std::endl << "arr2" << std::endl << arr2 << std::endl;
  std::cout << "arr1.transpose()" << std::endl;
  arr1.transpose();
  std::cout << arr1 << std::endl;
  std::cout << "mult(arr2, arr1) " << std::endl;
  std::cout << ndarray<>::mult(arr2, arr1) << std::endl;


  return 0;
}