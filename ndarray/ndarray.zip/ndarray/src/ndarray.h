#pragma once
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <initializer_list>
#include <limits>
#include <memory>
#include <ostream>
#include <random>
#include <stdexcept>
#include <vector>
template <typename T = int>
class ndarray {
public:
  using value_type = T;
  using shape_type = std::vector<size_t>;
  using data_type = std::vector<T>;
  static_assert(std::is_arithmetic_v<T>, "not an arithmetic type");

  void verify() const {
    if (_shapes.empty()) {
      throw std::logic_error("zero-valued dim");
    }
    if (_data.empty()) {
      throw std::logic_error("no data");
    }
    if (_data.size() < adjust_size(_shapes)) {
      throw std::logic_error("can not ajust stride to shape");
    }

    if (_shapes.size() > 2) {
      throw std::logic_error("unsupported dims count");
    }
  }
  ndarray(shape_type shape, size_t fill = 0)
      : _shapes(std::move(shape)), _data(adjust_size(_shapes), fill) {

    verify();
  }

  ndarray(shape_type shape, data_type strides)
      : _shapes(std::move(shape)), _data(std::move(strides)) {
    verify();
  }

  struct shape_indexer {
    shape_indexer(const shape_type &handler) : _reference(handler) {}

    std::reference_wrapper<const shape_type> _reference;
    size_t ext(size_t i) const { return _reference.get()[i]; }
    size_t index(const std::vector<size_t> &ids) const {
      if (ids.size() != _reference.get().size()) {
        throw std::logic_error("incompatible basis");
      }
      auto ret = ids.back();
      for (auto i = ids.size() - 1; i--;) {
        ret += ids[i] * _reference.get()[i + 1];
      }
      return ret;
    }
    size_t index(std::initializer_list<size_t> ids) const {
      if (ids.size() != _reference.get().size()) {
        throw std::logic_error("incompatible basis");
      }
      auto ret = *std::next(ids.begin(), ids.size() - 1);
      for (auto i = ids.size() - 1; i--;) {
        ret += *std::next(ids.begin(), i) * _reference.get()[i + 1];
      }
      return ret;
    }

    shape_type reverse() const {
      auto ret = _reference.get();
      std::reverse(ret.begin(), ret.end());
      return ret;
    }
  };

  static ndarray zeros(shape_type shape) { return ndarray(std::move(shape)); }
  static ndarray ones(shape_type shape) { return ndarray(std::move(shape), 1); }
  static ndarray rands(shape_type shape, T min = 0,
                       T max = std::numeric_limits<T>::max()) {
    ndarray<T> ret(std::move(shape));
    static std::random_device rnd_device;
    // Specify the engine and distribution.
    static std::mt19937 mersenne_engine{
        rnd_device()}; // Generates random integers
    if constexpr (std::is_integral_v<T>) {

      std::uniform_int_distribution<T> dist{min, max};
      std::generate(ret._data.begin(), ret._data.end(),
                    [&dist]() { return dist(mersenne_engine); });
    } else {
      std::uniform_int_distribution<uint64_t> dist{min, max};
      auto zero_one = [&dist]() {
        auto num = dist(mersenne_engine);
        return static_cast<T>(num) /
               static_cast<T>(std::numeric_limits<uint64_t>::max());
      };
      std::generate(ret._data.begin(), ret._data.end(), [&dist, &zero_one]() {
        return dist(mersenne_engine) + zero_one();
      });
    }
    return ret;
  }
  const shape_type &shapes() const noexcept { return _shapes; }
  std::ostream &plain_stringify(std::ostream &o) const {
    for (const auto &i : _data) {
      o << i << ' ';
    }
    return o;
  }
  friend std::ostream &operator<<(std::ostream &o, const ndarray &arg) {

    const auto &ext = arg._shapes;
    auto e = shape_indexer(ext);
    for (auto i = 0u; i < (e.ext(0)); ++i) {
      for (auto j = 0u; j < (e.ext(1)); ++j) {
        o << arg._data[e.index({i, j})] << ' ';
      }
      o << '\n';
    }
    return o;
  }

  ndarray &operator+=(
      const ndarray &rhs) // compound assignment (does not need to be a member,
  {                       // but often is, to modify the private members)
    if (!dim_eq(rhs)) {
      throw std::logic_error("incompatible dimentions");
    }
    for (size_t i = 0; i < _data.size(); ++i) {
      _data[i] += rhs._data[i];
    }

    return *this; // return the result by reference
  }

  friend ndarray operator+(
      ndarray lhs,        // passing lhs by value helps optimize chained a+b+c
      const ndarray &rhs) // otherwise, both parameters may be const references
  {
    lhs += rhs; // reuse compound assignment
    return lhs; // return the result by value (uses move constructor)
  }

  ndarray &operator-=(
      const ndarray &rhs) // compound assignment (does not need to be a member,
  {                       // but often is, to modify the private members)
    if (!dim_eq(rhs)) {
      throw std::logic_error("incompatible dimentions");
    }
    for (size_t i = 0; i < _data.size(); ++i) {
      _data[i] -= rhs._data[i];
    }

    return *this; // return the result by reference
  }

  friend ndarray operator-(
      ndarray lhs,        // passing lhs by value helps optimize chained a+b+c
      const ndarray &rhs) // otherwise, both parameters may be const references
  {
    lhs -= rhs; // reuse compound assignment
    return lhs; // return the result by value (uses move constructor)
  }

  ndarray &operator*=(
      const ndarray &rhs) // compound assignment (does not need to be a member,
  {                       // but often is, to modify the private members)
    if (!dim_eq(rhs)) {
      throw std::logic_error("incompatible dimentions");
    }
    for (size_t i = 0; i < _data.size(); ++i) {
      _data[i] *= rhs._data[i];
    }

    return *this; // return the result by reference
  }

  friend ndarray operator*(
      ndarray lhs,        // passing lhs by value helps optimize chained a+b+c
      const ndarray &rhs) // otherwise, both parameters may be const references
  {
    lhs *= rhs; // reuse compound assignment
    return lhs; // return the result by value (uses move constructor)
  }

  ndarray &operator/=(
      const ndarray &rhs) // compound assignment (does not need to be a member,
  {                       // but often is, to modify the private members)
    if (!dim_eq(rhs)) {
      throw std::logic_error("incompatible dimentions");
    }
    for (size_t i = 0; i < _data.size(); ++i) {
      if (rhs._data[i] == 0) {
        throw std::logic_error("division by zero");
      }
      _data[i] /= rhs._data[i];
    }

    return *this; // return the result by reference
  }

  friend ndarray operator/(
      ndarray lhs,        // passing lhs by value helps optimize chained a+b+c
      const ndarray &rhs) // otherwise, both parameters may be const references
  {
    lhs /= rhs; // reuse compound assignment
    return lhs; // return the result by value (uses move constructor)
  }

  const T &operator[](const std::vector<size_t> &i) const {
    return _data[shape_indexer(shapes()).index(i)];
  }
  const T &operator[](std::initializer_list<size_t> i) const {
    return _data[shape_indexer(shapes()).index(i)];
  }

  T &operator[](const std::vector<size_t> &i) {
    return _data[shape_indexer(shapes()).index(i)];
  }
  T &operator[](std::initializer_list<size_t> i) {
    return _data[shape_indexer(shapes()).index(i)];
  }

  ndarray &transpose() {
    if (_shapes.size() == 1) {
      return *this;
    }
    auto e = shape_indexer(shapes());
    auto new_ext = e.reverse();
    auto transposed = zeros(new_ext);
    for (auto i = 0u; i < e.ext(0); ++i) {
      for (auto j = 0u; j < e.ext(1); ++j) {
        transposed[{j, i}] = (*this)[{i, j}];
      }
    }
    *this = std::move(transposed);
    return *this;
  }

  static ndarray mult(ndarray lhs, const ndarray &rhs) {
    auto &e1 = lhs.shapes();
    auto &e2 = rhs.shapes();

    if (e2.front() != e1.back()) {
      throw std::logic_error("incompatible dims");
    }
    auto mult_range = rhs._shapes.front();
    auto res = zeros({lhs._shapes.front(), rhs.shapes().back()});

    auto e = shape_indexer(res.shapes());

    for (auto i = 0u; i < e.ext(0); ++i) {
      for (auto j = 0u; j < e.ext(1); ++j) {

        for (auto r = 0u; r < mult_range - 1; ++r) {
          res[{i, j}] += lhs[{i, r}] * rhs[{r, j}];
        }
      }
    }
    return res;
  }

  double mean() const {
    auto sum = std::accumulate(_data.begin(), _data.end(), 0);
    return static_cast<double>(sum) / _data.size();
  }
  std::vector<double> mean(size_t dim) const {
    if (dim > _shapes.size() - 1) {
      throw std::logic_error("no such dim");
    }
    std::vector<double> ret;
    auto e = shape_indexer(shapes());
    if (_shapes.size() == 1) {
      ret.emplace_back(mean());
      return ret;
    }

    for (auto i = 0u; i < e.ext(!dim); ++i) {
      auto sum = 0u;
      for (auto j = 0u; j < e.ext(dim); ++j) {
        sum += dim ? (*this)[{i, j}] : (*this)[{j, i}];
      }
      ret.emplace_back(static_cast<double>(sum) / e.ext(dim));
    }

    return ret;
  }

private:
  shape_type _shapes;
  data_type _data;

  inline size_t adjust_size(const shape_type &shape,
                            size_t init = 1) const {
    for (auto &item : shape)
      init = std::move(init) * item;

    return init;
  }
  bool dim_eq(const ndarray &arg) const { return _shapes == arg._shapes; }
};
